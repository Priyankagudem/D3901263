package uk.ac.tees.mad.d3901263.screens.authentication.domain

data class LoginUiState(
    val email: String = "",
    val password: String = ""
)