package uk.ac.tees.mad.d3901263.domain

data class Location(
    val latitude: Double? = null,
    val longitude: Double? = null
)