package uk.ac.tees.mad.d3901263.ui.theme

import androidx.compose.ui.graphics.Color

val primaryPink = Color(0xFFE75A5A)
val darkGrey = Color(0xFF262626)
val lightGrey = Color(0xFF797979)
val smokeWhite = Color(0xFFE0E0E0)