package uk.ac.tees.mad.d3901263.screens.authentication.domain

data class UserData(
    val userId: String,
    val username: String?,
    val email: String?
)