package uk.ac.tees.mad.d3901263.application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BeautyAppointmentApp: Application() {
}