package uk.ac.tees.mad.d3901263.screens.authentication.domain

data class RegisterUiState(
    val name: String = "",
    val email: String = "",
    val password: String = ""
)